jQuery('document').ready(function(){

$('document').ready(function(){
	$('#main').on('click',function(){
		
})
	$('#news').on('click',function(){
		
})
	$('#projects').on('click',function(){
		
})
	$('#forum').on('click',function(){
		
})
	$('#find').on('click',function(){
		
})
    });
});